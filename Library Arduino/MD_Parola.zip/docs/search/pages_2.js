var searchData=
[
  ['parola_20library_0',['Parola Library',['../page_software.html',1,'index']]]
];
