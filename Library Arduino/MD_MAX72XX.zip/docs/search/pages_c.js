var searchData=
[
  ['software_20library_0',['Software Library',['../page_software.html',1,'index']]],
  ['support_20the_20library_1',['Support the Library',['../page_donation.html',1,'index']]],
  ['system_20connections_2',['System Connections',['../page_connect.html',1,'index']]]
];
